public class Main {
    public static void main(String[] args) {

        int x = 10;
        int y = x++;			// post-increment
        System.out.println(x);
        System.out.println(y);
    
    
  }
}