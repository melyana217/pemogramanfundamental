import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    String[] Bulan = {
        "Januari",
        "Februari",
        "Maret",
        "April",
        "Mei",
        "Juni",
        "Juli",
        "Agustus",
        "September",
        "Oktober",
        "November",
        "Desember",
    };
    
    Scanner n = new Scanner (System.in);
    int tanggal = n.nextInt();
    int nobulan = n.nextInt();
    int tahun = n.nextInt();
  
      System.out.println(tanggal + Bulan[nobulan-1] + tahun);
    
    
  }
}