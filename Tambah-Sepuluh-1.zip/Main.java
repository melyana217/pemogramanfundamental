class Main {
  public static void main(String[] args) {
    int nilai = 2147483647 + 10;
    System.out.println( nilai + nilai );
  }
}